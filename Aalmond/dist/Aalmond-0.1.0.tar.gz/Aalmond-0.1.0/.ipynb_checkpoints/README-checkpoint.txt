v =========== * =========== * =========== * =========== * =========== * =========== v

Project : Aalmond!
Contents: This file contains three (3) Function Definitions that provides Primary EDA (Exploratory Data Analysis) functionality: 
Function: Dataframe Vital Stats, Outliers Detection, Data View from various sections of a DataFrame.

1. vitalStats() : Displays Pandas DataFrame Vital Stats, an exended output of seeded describe()
2. showdfQ()    : Displays data rows of a Pandas DataFrame selectively from Mid, Mid Q1, Mid Q3 section of a Dataframe
3. showOutL()   : Displays and/or Imputes Outlier values, based on IQR Method, of Pandas DataFrame Numeric Column(s) 

Usage, Parameter & General Notes documented inside each function as Docstring.

^ =========== * =========== * =========== * =========== * =========== * =========== ^
